Noah Serr V00891494
SENG 474 Assignment 2

To run this code, navigate to the /A2/ directory, and use `python [filename].py`. This will result in graphs being created for each classifier, and saved to the /A2/ directory.

mnist_reader.py was copied from the fashion-mnist-master directory.

References:
https://github.com/zalandoresearch/fashion-mnist
https://scikit-learn.org/stable/modules/generated/sklearn.linear_model.LogisticRegression.html
https://scikit-learn.org/stable/modules/generated/sklearn.svm.SVC.html
https://machinelearningmastery.com/k-fold-cross-validation/