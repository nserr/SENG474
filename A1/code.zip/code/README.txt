Noah Serr V00891494
SENG 474 Assignment 1

To run this code, navigate to the /A1/ directory, and use `python3 [filename].py`. This will result in graphs being created for each dataset using each method, and saved to the /A1/ directory.

Code for each method of this assignment was adapted partially from https://scikit-learn.org/stable/auto_examples/.

The second dataset (the wheat seeds dataset) was taken from https://machinelearningmastery.com/standard-machine-learning-datasets/.